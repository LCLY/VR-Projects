Retro Racer (for Wavefront OBJ) 
c 2013 Vanishing Point

All of this product's content was created by Sparkyworld. Uploaded for sale here with permission.

Directions:
Extract the files into any folder

Using the model:
1) Start your favorite modelling or rendering program.
2) Import the model into your scene.
(If necessary, follow the instructions in your software program's manual).


Notes:

1) You'll need to resize the model to suit the needs of your scene.

2) Please refer to your software manual about how to re-color or adjust the surface materials.

3) Please refer to your software manual about how to adjust the "smooth angle" or "crease angle" to create smooth surfaces.

4) This version of the model includes "group" information, which your software should interpret as separate parts.

Usage License:
You are completely free to use this figure in any commercial or non-commercial render, image, or animation.
You may NOT sell or give away any files found in this zip package without express permission.
You are free to redistribute your own textures as you wish, provided they do not use any images found in this zip file. 

-----------------------------------
